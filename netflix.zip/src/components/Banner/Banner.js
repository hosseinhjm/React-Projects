import React,{useState,useEffect} from 'react';
import axios from 'axios';
import { API_Key,imageUrl } from '../../constants/BaseUrl';
import styles from './Banner.module.css';

const Banner = () => {

    const [movie, setMovies] = useState();
    // console.log(movie,"movie");

    useEffect(() => {
        axios.get(`https://api.themoviedb.org/3/trending/all/day?api_key=${API_Key}`)
            .then(response => {
                console.log(response.data.results)
                let pic = response.data.results[Math.floor(Math.random() * response.data.results.length)]
                setMovies(pic)
                // setMovies(response.data.results[0])
            })
    }, [])
    return (
        <>
            <div style={{backgroundImage:`url(${movie? imageUrl+movie.backdrop_path : ""})`}} className={styles.banner}>
                <div className={styles.content}>
                    <h1 className={styles.title}>{movie?movie.title :""}</h1>
                    <div className={styles.banner_button}>
                        <button className={styles.button}>Play</button>
                        <button className={styles.button}>My list</button>
                    </div>
                    <h1 className={styles.discription}>{movie? movie.overview : ""}</h1>
                </div>
                <div>
                    <div className={styles.fade_bottom}></div>
                </div>
            </div>
        </>
    );
};

export default Banner;
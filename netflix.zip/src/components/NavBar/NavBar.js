import React,{useState,useEffect} from 'react';
// import styles from './NavBar.module.css';
import './NavBar.css';

const NavBar = () => {

    const [color, setColor] = useState(false);
    const changeColor = () =>{
        if(window.scrollY >= 50){
            setColor(true)
        }else {
            setColor(false)
        }
    }

    useEffect(()=>{
        changeColor();
        window.addEventListener("scroll", changeColor)
    })
    
    return (
        <nav className = {color ? 'navbar changeBg' : 'navbar'}>
            <div className={'navbar'}>
                <img className={'logo'} src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Netflix_2015_logo.svg/1920px-Netflix_2015_logo.svg.png" alt="" />
                {/* <img className={styles.avatar} src="https://i.pinimg.com/originals/0d/dc/ca/0ddccae723d85a703b798a5e682c23c1.png" alt="" /> */}
                <button className={'button'}>Sign in</button>
            </div>
        </nav>

    );
};

export default NavBar;
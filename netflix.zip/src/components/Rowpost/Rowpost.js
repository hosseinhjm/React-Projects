import React,{useState,useEffect} from 'react';
import axios from 'axios';
import Youtube from 'react-youtube';
import { API_Key,imageUrl } from '../../constants/BaseUrl';

// css
import styles from './Rowpost.module.css';


const Rowpost = (props) => {

    const [movies, setMovies] = useState([]);
    const [urlId, setUrlId] = useState('');

    useEffect(() => {
        axios.get(props.url).then(response => {
            console.log(response.data,"Row Posts")
            setMovies(response.data.results)
          }).catch(err => {
            alert("Network Error")
          })
    }, [props])

    const opts = {
        height: '390',
        width: '100%',
        playerVars: {
          // https://developers.google.com/youtube/player_parameters
          autoplay: 1,
        },
    };

    const handleMovie = (id)=>{
        console.log(id,"id");
          axios.get(`https://api.themoviedb.org/3/movie/${id}/videos?api_key=${API_Key}&language=en-US`).then(response => {
            console.log(response.data);
            if(response.data.results.length !== 0){
              setUrlId(response.data.results[0])
            }else{
              alert('NO Records Found')
            }
          }).catch((err)=>{
            if(err.response){
              alert('NO Records Found')
            }
          })
    }

    return (
        <>
            <div className={styles.rowpost}>
                <h1>{props.title}</h1>
                <div className={styles.posters}>
                    {movies.map((obj)=>
                    <img key={obj.id} onClick={()=>handleMovie(obj.id)} className={props.isSmall ? styles.smallPoster : styles.poster} src={props.isSmall ? `${imageUrl+obj.backdrop_path}` : `${imageUrl+obj.poster_path}`} alt="poster" />
                    )}
                </div>
                { urlId &&  <Youtube videoId={urlId.key} opts={opts} />  } 
            </div>
        </>
    );
};

export default Rowpost;
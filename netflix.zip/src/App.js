import React from 'react';
import './App.css';
// components
import Banner from './components/Banner/Banner';
import NavBar from './components/NavBar/NavBar';
import {originals,action,romance,horror,science_fiction,animation,comady} from './constants/BaseUrl';
import Rowpost from './components/Rowpost/Rowpost';
import Footer from './components/Footer/Footer';

function App() {
  return (
    <div className="App">
      <NavBar />
      <Banner />
      <Rowpost url={originals} title='Netflix originals'/>  
      <Rowpost url={action} title='Action' isSmall />
      <Rowpost url={romance} title='Romantic films' isSmall />
      <Rowpost url={science_fiction} title='Popular sci-fi films' isSmall />
      <Rowpost url={horror} title='Popular horror films' isSmall />
      <Rowpost url={animation} title='Popular animated films' isSmall />
      <Rowpost url={comady} title='Popular comedies' isSmall />
      <Footer/>
    </div>
  );
}

export default App;
